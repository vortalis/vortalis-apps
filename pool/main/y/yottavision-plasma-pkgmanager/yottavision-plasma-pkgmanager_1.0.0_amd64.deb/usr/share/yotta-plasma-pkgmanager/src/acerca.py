import gi
import sys

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf

class AboutWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Acerca del Gestor de Aplicaciones Yottavision OS")
        self.set_default_size(400, 500)
        self.set_border_width(10)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(vbox)
        
        # Cargar y mostrar la imagen centrada
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale("/usr/share/yotta-pkgmanager/src/yotta.png", 200, 200, True)
            image = Gtk.Image.new_from_pixbuf(pixbuf)
            image.set_halign(Gtk.Align.CENTER)
            vbox.pack_start(image, False, False, 0)
        except Exception as e:
            print(f"Error al cargar la imagen: {e}")
        
        # Etiqueta de título
        title_label = Gtk.Label(label="<b>Gestor de aplicaciones Yottavision OS</b>")
        title_label.set_use_markup(True)
        title_label.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(title_label, False, False, 0)
        
        # Texto de derechos
        info_label = Gtk.Label(label="(c) 2025 Equipo Yottavision OS.\nLicencia libre por definir")
        info_label.set_justify(Gtk.Justification.CENTER)
        vbox.pack_start(info_label, False, False, 0)
        
        # Notebook con pestañas
        notebook = Gtk.Notebook()
        vbox.pack_start(notebook, True, True, 0)
        
        tabs = {
            "Sobre esta app": "Esta aplicación permite instalar y desinstalar múltiples aplicaciones de forma masiva en Yottavision OS.",
            "Sobre las categorías": "Las aplicaciones están organizadas en distintas categorías para facilitar su búsqueda.",
            "Advertencias de uso": "Usar con precaución. La instalación y eliminación de software puede afectar el sistema.",
            "Más información": "Visita nuestro sitio web o consulta la documentación oficial de Yottavision OS."
        }
        
        for title, content in tabs.items():
            label = Gtk.Label(label=content)
            label.set_justify(Gtk.Justification.FILL)
            scrolled = Gtk.ScrolledWindow()
            scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scrolled.add(label)
            notebook.append_page(scrolled, Gtk.Label(label=title))
        
        # Botón OK para cerrar
        button = Gtk.Button(label="OK")
        button.connect("clicked", self.on_close)
        button.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(button, False, False, 10)
        
    def on_close(self, widget):
        Gtk.main_quit()

if __name__ == "__main__":
    win = AboutWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
