import os
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Ruta donde se guardarán los íconos
DIRECTORIO_ICONOS = '/tmp/yotta_iconos/'

# Asegurémonos de que el directorio de íconos exista
if not os.path.exists(DIRECTORIO_ICONOS):
    os.makedirs(DIRECTORIO_ICONOS)

# Configurar opciones para usar Chromium sin abrir una ventana (modo headless)
options = Options()
options.add_argument("--headless")  # No mostrar la ventana del navegador
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

# Usar el path correcto de chromedriver para Chromium
chromedriver_path = '/usr/bin/chromedriver'

# Crear el servicio para el WebDriver
service = Service(chromedriver_path)

# Función para obtener el ícono
def obtener_icono(nombre_app):
    url = f"https://flathub.org/apps/search?q={nombre_app.replace(' ', '+')}"

    # Crear el driver de Selenium
    driver = webdriver.Chrome(service=service, options=options)
    driver.get(url)

    try:
        # Esperamos hasta que el primer ícono sea visible en la página
        icono_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//img[contains(@src, 'icon')]"))
        )

        # Obtener la URL del ícono
        icono_url = icono_element.get_attribute("src")

        # Si se encuentra el ícono, descargarlo
        if icono_url:
            # Descargar la imagen
            response = requests.get(icono_url)
            if response.status_code == 200:
                nombre_archivo = f"{nombre_app.replace(' ', '_').lower()}.png"
                path_icono = os.path.join(DIRECTORIO_ICONOS, nombre_archivo)

                with open(path_icono, 'wb') as file:
                    file.write(response.content)
                return path_icono
    except Exception as e:
        print(f"Error al obtener el ícono: {e}")

    driver.quit()
    return None

# Función para interactuar con el usuario desde la terminal
def main():
    while True:
        nombre_app = input("Ingrese el nombre de la aplicación (o 'salir' para terminar): ").strip()
        if nombre_app.lower() == 'salir':
            break

        if nombre_app:
            print(f"Buscando el ícono para '{nombre_app}'...")
            icono_path = obtener_icono(nombre_app)
            if icono_path:
                print(f"Ícono descargado y guardado en: {icono_path}")
            else:
                print("No se pudo obtener el ícono.")
        else:
            print("Por favor, ingrese un nombre de aplicación válido.")

if __name__ == "__main__":
    main()
