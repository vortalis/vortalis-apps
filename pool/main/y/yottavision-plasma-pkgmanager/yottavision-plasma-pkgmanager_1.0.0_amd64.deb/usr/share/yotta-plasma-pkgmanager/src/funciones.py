import os
import subprocess
import threading
from gi.repository import GLib

def get_installed_apps():
    try:
        result = subprocess.run(["dpkg", "-l"], capture_output=True, text=True, check=True)
        return [line.split()[1] for line in result.stdout.splitlines() if line.startswith("ii ")]
    except subprocess.CalledProcessError as e:
        print(f"Error al obtener apps APT: {e}")
        return []

def get_flatpak_installed():
    try:
        result = subprocess.run(["flatpak", "list", "--app", "--columns=application"],
                               capture_output=True, text=True, check=True)
        return [line.strip() for line in result.stdout.splitlines() if line.strip()]
    except subprocess.CalledProcessError as e:
        print(f"Error al obtener apps Flatpak: {e}")
        return []

def apply_batch_changes(install_list, uninstall_list, callback):
    def thread_func():
        success = True
        try:
            # Instalaciones APT
            apt_install = [app.name for app in install_list if app.source == "APT"]
            if apt_install:
                subprocess.run(["pkexec", "apt-get", "install", "-y"] + apt_install,
                              check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Desinstalaciones APT
            apt_uninstall = [app.name for app in uninstall_list if app.source == "APT"]
            if apt_uninstall:
                subprocess.run(["pkexec", "apt-get", "remove", "-y"] + apt_uninstall,
                              check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Instalaciones Flatpak
            flatpak_install = [app.name for app in install_list if app.source == "Flatpak"]
            if flatpak_install:
                subprocess.run(["flatpak", "install", "--user", "-y", "flathub"] + flatpak_install,
                              check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            # Desinstalaciones Flatpak
            flatpak_uninstall = [app.name for app in uninstall_list if app.source == "Flatpak"]
            if flatpak_uninstall:
                subprocess.run(["flatpak", "uninstall", "--user", "-y"] + flatpak_uninstall,
                              check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        except subprocess.CalledProcessError as e:
            print(f"Error en proceso: {e.stderr.decode()}")
            success = False

        GLib.idle_add(callback, success)

    threading.Thread(target=thread_func, daemon=True).start()

def install_package(package):
    try:
        result = subprocess.run(["pkexec", "apt-get", "install", "-y", package],
                               capture_output=True, text=True, check=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def remove_package(package):
    try:
        result = subprocess.run(["pkexec", "apt-get", "remove", "-y", package],
                               capture_output=True, text=True, check=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def install_flatpak(package):
    try:
        result = subprocess.run(["flatpak", "install", "--user", "-y", "flathub", package],
                               capture_output=True, text=True, check=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def remove_flatpak(package):
    try:
        result = subprocess.run(["flatpak", "uninstall", "--user", "-y", package],
                               capture_output=True, text=True, check=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr
