#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# plasma.py - Gestor de Aplicaciones para KDE Plasma

import sys
import os
import subprocess
import uuid
from typing import Dict, List, Optional

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QComboBox, QListWidget, QListWidgetItem, QLabel, QPushButton,
    QMessageBox, QSplitter, QStyleFactory, QSizePolicy, QSpacerItem,
    QStyle, QProgressDialog
)
from PyQt5.QtCore import (
    Qt, QSize, QProcess, QTimer, QThread, pyqtSignal,
    QObject, QEventLoop, QEvent
)
from PyQt5.QtGui import (
    QIcon, QPixmap, QFont, QImage, QPainter, QColor, QPen
)

from lista import app_data, App
from funciones import get_installed_apps, get_flatpak_installed
from scraperflathub import obtener_icono

ICONOS_CACHE = "/tmp/yotta_iconos/"
os.makedirs(ICONOS_CACHE, exist_ok=True)

class KDEAppManager(QMainWindow):
    process_output = pyqtSignal(str, str)
    update_ui = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestor de Aplicaciones Yottavision OS")
        self.setMinimumSize(450, 500)
        self.setWindowIcon(QIcon("/usr/share/icons/hicolor/scalable/apps/yotta-plasma-pkgmanager.svg"))
        self.active_threads = []
        self.current_category_id = None
        self.cached_categories = {}
        self._setup_ui()
        self._load_config()
        self._connect_signals()
        self.selected_app = None

    def _setup_ui(self):
        #self.setStyle(QStyleFactory.create(QApplication.style().objectName()))
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # Encabezado - Nueva estructura para alinear spinner
        header_layout = QHBoxLayout()

        # Contenedor izquierdo: Combobox + Spinner en misma fila
        left_header = QHBoxLayout()
        left_header.setContentsMargins(0, 0, 0, 0)
        left_header.setSpacing(15)

        # Combobox con su label en vertical
        category_box = QVBoxLayout()
        category_box.setSpacing(0)
        category_box.setContentsMargins(0, 0, 0, 0)
        self.category_label = QLabel("<b>Categorías de aplicaciones:</b>")
        self.category_combo = QComboBox()
        self.category_combo.addItems(app_data.keys())
        self.category_label.setStyleSheet("margin-bottom: 2px;")  # Reducir espacio bajo la etiqueta
        self.category_combo.setStyleSheet("margin-top: 1px;")  # Reducir espacio sobre el combobox
        category_box.addWidget(self.category_label)
        category_box.addWidget(self.category_combo)
        left_header.addLayout(category_box)

        # Spinner alineado verticalmente al fondo
        self.category_spinner = QProgressIndicator()
        left_header.addWidget(self.category_spinner, 0, Qt.AlignBottom)

        header_layout.addLayout(left_header)
        header_layout.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))

        # Logo en tamaño original
        logo_path = "/usr/share/yotta-plasma-pkgmanager/src/yotta.png"
        if os.path.exists(logo_path):
            self.logo = QLabel()
            self.logo.setPixmap(QPixmap(logo_path))  # Sin escalado
            header_layout.addWidget(self.logo, 0, Qt.AlignRight)

        main_layout.addLayout(header_layout)

        # Lista de aplicaciones
        self.app_list = QListWidget()
        self.app_list.setIconSize(QSize(24, 24))
        self.app_list.setStyleSheet("""
            QListWidget::item {
                padding: 5px;
                border-bottom: 1px solid palette(mid);
            }
            QListWidget::item {
            padding: 5px;
            border-bottom: 1px solid palette(mid);
        }
        QListWidget::item:selected {
            background-color: palette(highlight);
            color: palette(highlighted-text);
            border-radius: 3px;
        }
        QListWidget::item:!active {
            selection-background-color: palette(highlight);
            selection-color: palette(highlighted-text);
        }
        """)
        main_layout.addWidget(self.app_list)

        # Panel de detalles sin márgenes
        splitter = QSplitter(Qt.Horizontal)
        details_panel = QWidget()
        details_layout = QVBoxLayout(details_panel)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.setSpacing(5)

        # Encabezado detalles (icono + título)
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        self.app_icon = QLabel()
        self.app_icon.setFixedSize(48, 48)
        self.app_name = QLabel()
        self.app_name.setStyleSheet("""
            font-size: 14pt;
            font-weight: bold;
            margin-top: 0px;
        """)

        title_layout.addWidget(self.app_icon)
        title_layout.addWidget(self.app_name)
        title_layout.addStretch()
        details_layout.addLayout(title_layout)

        self.app_desc = QLabel()
        self.app_desc.setStyleSheet("margin-top: 0px;")
        self.app_desc.setWordWrap(True)
        details_layout.addWidget(self.app_desc)

        # Lista de cambios
        self.changes_list = QListWidget()
        self.changes_list.addItem("No hay tareas pendientes.")
        self.changes_list.setStyleSheet("""
            QListWidget {
                font-family: Monospace;
                font-size: 10pt;
            }
            QListWidget::item { padding: 3px; }
        """)

        splitter.addWidget(details_panel)
        splitter.addWidget(self.changes_list)
        splitter.setSizes([400, 200])
        main_layout.addWidget(splitter)

        # Botones
        button_layout = QHBoxLayout()
        self.open_discover_btn = QPushButton("Abrir en Discover")
        self.apply_btn = QPushButton("Aplicar cambios")
        self.reset_btn = QPushButton("Restablecer")
        self.about_btn = QPushButton("Acerca de")

        self.open_discover_btn.setIcon(QIcon.fromTheme("internet-web-browser"))
        self.apply_btn.setIcon(QIcon.fromTheme("dialog-ok-apply"))
        self.reset_btn.setIcon(QIcon.fromTheme("edit-undo"))
        self.about_btn.setIcon(QIcon.fromTheme("help-about"))

        button_layout.addWidget(self.open_discover_btn)
        button_layout.addWidget(self.apply_btn)
        button_layout.addWidget(self.reset_btn)
        button_layout.addItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        button_layout.addWidget(self.about_btn)
        main_layout.addLayout(button_layout)

    def _load_config(self):
        self.initial_state = {}
        installed_apt = set(get_installed_apps())
        installed_flatpak = set(get_flatpak_installed())

        for category in app_data.values():
            for app in category:
                self.initial_state[app.name] = app.name in installed_apt or app.name in installed_flatpak
        self.current_state = self.initial_state.copy()

    def _connect_signals(self):
        self.category_combo.currentTextChanged.connect(self._load_category_async)
        self.apply_btn.clicked.connect(self._apply_changes)
        self.reset_btn.clicked.connect(self._reset_selection)
        self.about_btn.clicked.connect(self._open_about)
        self.open_discover_btn.clicked.connect(self._open_in_discover)
        self.app_list.itemClicked.connect(self._show_app_details)
        self.app_list.itemChanged.connect(self._update_pending_actions)
        QTimer.singleShot(0, self._load_initial_category)

    def _load_initial_category(self):
        self.category_combo.setCurrentIndex(0)
        self._load_category(self.category_combo.currentText())

    def _load_category_async(self):
        QTimer.singleShot(0, lambda: self._load_category(self.category_combo.currentText()))

    def _load_category(self, category):
        self.category_spinner.start()

        if self.current_category_id:
            old_loader = getattr(self, 'category_loader', None)
            if old_loader and old_loader.isRunning():
                old_loader.quit()
                old_loader.wait(100)

        if category in self.cached_categories:
            self._add_category_items(self.cached_categories[category])
            self.category_spinner.stop()
            return

        self.current_category_id = str(uuid.uuid4())
        self.category_loader = CategoryLoader(
            category,
            self.current_state,
            self.current_category_id
        )
        self.category_loader.items_loaded.connect(self._handle_category_loaded)
        self.category_loader.start()

    def _handle_category_loaded(self, items):
        self.category_spinner.stop()
        if self.current_category_id != self.category_loader.category_id:
            return
        self.cached_categories[self.category_combo.currentText()] = items.copy()
        self._add_category_items(items)

    def _add_category_items(self, items):
        self.app_list.clear()
        for item_data in items:
            new_item = QListWidgetItem(item_data.text())
            new_item.setData(Qt.UserRole, item_data.data(Qt.UserRole))
            new_item.setCheckState(item_data.checkState())
            new_item.setIcon(item_data.icon())
            self.app_list.addItem(new_item)
        QApplication.processEvents()

    def _show_app_details(self, item):
        self.selected_app = item.data(Qt.UserRole)
        if not self.selected_app: return

        target_size = 48
        cache_path = os.path.join(ICONOS_CACHE, f"{self.selected_app.name.replace(' ', '_')}.png")

        if os.path.exists(cache_path):
            pixmap = QPixmap(cache_path).scaled(target_size, target_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        elif QIcon.hasThemeIcon(self.selected_app.name):
            pixmap = QIcon.fromTheme(self.selected_app.name).pixmap(target_size, target_size)
        else:
            icon_path = obtener_icono(self.selected_app.display_name)
            if icon_path and os.path.exists(icon_path):
                pixmap = QPixmap(icon_path).scaled(target_size, target_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            else:
                pixmap = QIcon.fromTheme("application-x-executable").pixmap(target_size, target_size)

        self.app_icon.setPixmap(pixmap)
        self.app_name.setText(self.selected_app.display_name)
        status = "Instalado" if self.current_state.get(self.selected_app.name) else "No instalado"
        self.app_desc.setText(f"{self.selected_app.description}\n\nEstado: {status}")

    def _open_in_discover(self):
        if self.selected_app:
            try:
                if self.selected_app.source == "Flatpak":
                    subprocess.Popen(["plasma-discover", f"appstream://{self.selected_app.name}"])
                else:
                    subprocess.Popen(["plasma-discover", "--search", self.selected_app.name])
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Error al abrir Discover: {str(e)}")

    def _update_pending_actions(self):
        self.changes_list.clear()
        has_changes = False

        for i in range(self.app_list.count()):
            item = self.app_list.item(i)
            app = item.data(Qt.UserRole)
            current_state = item.checkState() == Qt.Checked

            if current_state != self.initial_state.get(app.name, False):
                has_changes = True
                action = "Instalar" if current_state else "Desinstalar"
                change_item = QListWidgetItem(f"[PENDIENTE] {action}: {app.display_name}")
                change_item.setForeground(QColor("#2a76c6") if current_state else QColor("#c62a2a"))
                self.changes_list.addItem(change_item)

        if not has_changes:
            self.changes_list.clear()
            self.changes_list.addItem("No hay tareas pendientes.")

    def _reset_selection(self):
        self.current_state = self.initial_state.copy()
        self.cached_categories.clear()
        self._load_category(self.category_combo.currentText())
        self._update_pending_actions()

    def _apply_changes(self):
        changes = []
        for i in range(self.app_list.count()):
            item = self.app_list.item(i)
            app = item.data(Qt.UserRole)
            current_state = item.checkState() == Qt.Checked
            if current_state != self.initial_state.get(app.name, False):
                changes.append({"app": app, "install": current_state})

        if not changes:
            QMessageBox.information(self, "Sin cambios", "No hay cambios pendientes para aplicar.")
            return

        self.worker = ProcessWorker(changes)
        self.worker.output_received.connect(self._update_process_output)
        self.worker.finished.connect(self._handle_process_finish)
        self.worker.start()

    def _update_process_output(self, output, error):
        scroll_bar = self.changes_list.verticalScrollBar()
        auto_scroll = scroll_bar.value() == scroll_bar.maximum()

        if error:
            item = QListWidgetItem(f"❌ ERROR: {error.strip()}")
            item.setForeground(QColor("#ff4444"))
        else:
            item = QListWidgetItem(f"📄 {output.strip()}")
        self.changes_list.addItem(item)
        if auto_scroll:
            self.changes_list.scrollToBottom()

    def _handle_process_finish(self, success):
        if success:
            self._load_config()
            QMessageBox.information(self, "Éxito", "Cambios aplicados correctamente")
            self._load_category(self.category_combo.currentText())
        else:
            QMessageBox.critical(self, "Error", "Error durante la aplicación de cambios")

    def _open_about(self):
        subprocess.Popen(["python3", "/usr/share/yotta-plasma-pkgmanager/src/acerca.py"])

    def closeEvent(self, event):
        for thread in self.active_threads:
            if thread.isRunning():
                thread.quit()
                thread.wait(3000)
        event.accept()

class CategoryLoader(QThread):
    items_loaded = pyqtSignal(list)

    def __init__(self, category, current_state, category_id):
        super().__init__()
        self.category = category
        self.current_state = current_state
        self.category_id = category_id

    def run(self):
        try:
            items = []
            apps = app_data.get(self.category, [])
            for app in apps:
                if self.isInterruptionRequested():
                    return

                item = QListWidgetItem(app.display_name)
                item.setData(Qt.UserRole, app)
                item.setCheckState(Qt.Checked if self.current_state.get(app.name) else Qt.Unchecked)

                cache_path = os.path.join(ICONOS_CACHE, f"{app.name.replace(' ', '_')}.png")
                if os.path.exists(cache_path):
                    item.setIcon(QIcon(cache_path))
                elif QIcon.hasThemeIcon(app.name):
                    item.setIcon(QIcon.fromTheme(app.name))
                else:
                    icon_path = obtener_icono(app.display_name)
                    if icon_path and os.path.exists(icon_path):
                        item.setIcon(QIcon(icon_path))

                items.append(item)

            self.items_loaded.emit(items)
        except Exception as e:
            print(f"Error cargando categoría: {str(e)}")

class ProcessWorker(QThread):
    output_received = pyqtSignal(str, str)
    finished = pyqtSignal(bool)

    def __init__(self, changes):
        super().__init__()
        self.changes = changes

    def run(self):
        success = True
        try:
            apt_install = []
            apt_uninstall = []
            flatpak_install = []
            flatpak_uninstall = []

            for change in self.changes:
                app = change["app"]
                if change["install"]:
                    if app.source == "APT": apt_install.append(app.name)
                    else: flatpak_install.append(app.name)
                else:
                    if app.source == "APT": apt_uninstall.append(app.name)
                    else: flatpak_uninstall.append(app.name)

            commands = []
            if apt_install: commands.append(f"apt-get install -y {' '.join(apt_install)}")
            if apt_uninstall: commands.append(f"apt-get remove -y {' '.join(apt_uninstall)}")
            if flatpak_install: commands.append(f"flatpak install -y flathub {' '.join(flatpak_install)}")
            if flatpak_uninstall: commands.append(f"flatpak uninstall -y {' '.join(flatpak_uninstall)}")

            if commands:
                process = subprocess.run(
                    ["pkexec", "bash", "-c", " && ".join(commands)],
                    check=True,
                    text=True,
                    capture_output=True
                )
                self.output_received.emit(process.stdout, "")

        except subprocess.CalledProcessError as e:
            self.output_received.emit("", e.stderr)
            success = False
        except Exception as e:
            self.output_received.emit("", str(e))
            success = False

        self.finished.emit(success)

class QProgressIndicator(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update)
        self.setFixedSize(28, 28)
        self._color = QColor(QApplication.palette().text().color())

    def _update(self):
        self._angle = (self._angle + 45) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.translate(12, 12)
        painter.rotate(self._angle)

        pen = QPen()
        pen.setWidth(2)
        pen.setCapStyle(Qt.RoundCap)
        pen.setColor(self._color)
        painter.setPen(pen)

        start_angle = 0 * 16
        span_angle = 270 * 16
        painter.drawArc(-8, -8, 16, 16, start_angle, span_angle)

    def start(self):
        self._timer.start(50)
        self.show()

    def stop(self):
        self._timer.stop()
        self.hide()

    def _update_color(self):
        self._color = QColor(QApplication.palette().text().color())
        self.update()

    def changeEvent(self, event):
        if event.type() == QEvent.PaletteChange:
            self._update_color()

if __name__ == "__main__":
    os.environ["QT_QPA_PLATFORMTHEME"] = "kde"
    app = QApplication(sys.argv)
    window = KDEAppManager()
    window.showMaximized()
    sys.exit(app.exec_())
